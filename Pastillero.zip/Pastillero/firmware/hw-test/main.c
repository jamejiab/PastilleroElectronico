/**
 * 
 */

#include "soc-hw.h"
#define alarma_1_seg	15
#define alarma_1_min	15
#define alarma_1_hor	0

#define alarma_2_seg	20
#define alarma_2_min	18
#define alarma_2_hor	0

#define alarma_3_seg	25
#define alarma_3_min	20
#define alarma_3_hor	0

#define alarma_4_seg	0
#define alarma_4_min	21
#define alarma_4_hor	0

//---------------------------------------------------------------------------
// LCD Functions
//---------------------------------------------------------------------------

void writeCharlcd (char letter) 
{
	char highnib;
	char lownib;
	highnib = letter&0xF0;
	lownib = letter&0x0F;

	i2c_write_lcd(ADDRESS_I2C_LCD,highnib|0b00001001);
	i2c_write_lcd(ADDRESS_I2C_LCD,highnib|0b00001101);
	i2c_write_lcd(ADDRESS_I2C_LCD,highnib|0b00001001);  

	i2c_write_lcd(ADDRESS_I2C_LCD,(lownib<<4)|0b00001001);
	i2c_write_lcd(ADDRESS_I2C_LCD,(lownib<<4)|0b00001101);
	i2c_write_lcd(ADDRESS_I2C_LCD,(lownib<<4)|0b00001001);

	msleep(2);
}

void writeCommandlcd (char command) 
{
	char highnib;
	char lownib;
	highnib = command&0xF0;
	lownib = command&0x0F;

	i2c_write_lcd(ADDRESS_I2C_LCD,highnib|0b00001000);
	i2c_write_lcd(ADDRESS_I2C_LCD,highnib|0b00001100);
	i2c_write_lcd(ADDRESS_I2C_LCD,highnib|0b00001000);  

	i2c_write_lcd(ADDRESS_I2C_LCD,(lownib<<4)|0b00001000);
	i2c_write_lcd(ADDRESS_I2C_LCD,(lownib<<4)|0b00001100);
	i2c_write_lcd(ADDRESS_I2C_LCD,(lownib<<4)|0b00001000);

	msleep(2);
}

void writeStringlcd (char *str) {
	char *c = str;
	while(*c) {
		writeCharlcd(*c);
		c++;
	}
}

void lcdInit ()
{  
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00111000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00111100);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00111000);
	nsleep(4500000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00111000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00111100);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00111000);
	nsleep(4500000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00111000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00111100);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00111000);
	nsleep(200000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00101000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00101100);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00101000);
	nsleep(50000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00101000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00101100);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00101000);
	nsleep(50000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b10001000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b10001100);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b10001000);
	nsleep(50000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00001000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00001100);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b00001000);
	nsleep(50000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b11001000);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b11001100);
	i2c_write_lcd(ADDRESS_I2C_LCD,0b11001000);
	msleep(2);
}

//---------------------------------------------------------------------------
// LCD Commands
//---------------------------------------------------------------------------

void clearDisplay() 
{	writeCommandlcd(0b00000001);
}

void returnHome()
{	writeCommandlcd(0b00000010);
}

void entryModeSet2()
{  	writeCommandlcd(0b00000110);
}

void entryModeSet()
{	writeCommandlcd(0b00000111);
}

void entryModeSet3()
{	writeCommandlcd(0b00000100);
}

void entryModeSet4()
{	writeCommandlcd(0b00000101);
}

void displayOff()
{	writeCommandlcd(0b00001000);
}

void displayOn()
{	writeCommandlcd(0b00001111);
}

void cursorShiftRight()
{	writeCommandlcd(0b00010100);
}

void cursorShiftLeft()
{	writeCommandlcd(0b00010000);
}

void displayShiftRight()
{	writeCommandlcd(0b00011100);
}

void displayShiftLeft()
{	writeCommandlcd(0b00011000);
}

void functionSet()
{	writeCommandlcd(0b00101000);
}

void displayAddress(uint8_t col, uint8_t row){
	int row_offsets[] = { 0x00, 0x40, 0x14, 0x54 };
	if(row>2){
		row = 2-1;
	}
        writeCommandlcd (0x80|(col + row_offsets[row]));
}
//---------------------------------------------------------------------------
// ASCII Converter 
//---------------------------------------------------------------------------

char asciiConv (char number)
{	return number+48;
}

char asciiConvLcd_Dig1 (char number)
{	char highnib;
	char lownib;
	highnib = number&0xF0;
	lownib = number&0x0F;
	return (lownib)+48;
}

char asciiConvLcd_Dig2 (char number)
{	char highnib;
	char lownib;
	highnib = number&0xF0;
	lownib = number&0x0F;
	return (highnib >> 4)+48;
}

inline void writeint(uint32_t val)
{
	uint32_t i, digit;

	for (i=0; i<8; i++) {
		digit = (val & 0xf0000000) >> 28;
		if (digit >= 0xA) 
			uart_putchar('A'+digit-10);
		else
			uart_putchar('0'+digit);
		val <<= 4;
	}
}



char glob[] = "Global";

volatile uint32_t *p;
volatile uint8_t *p2;

extern uint32_t tic_msec;

int main()
{
	unsigned int a = 20;
	unsigned int b = 180;
	int c = 0;
	servo_set_T0(a);
	servo_set_T1(a);
	servo_set_T2(a);
	servo_set_T3(a);

	char segundos = 0;
	char minutos = 0;
	char horas = 0;
	int sel = 0;

	lcdInit();
	clearDisplay();
	entryModeSet2();
	returnHome();
		
		while(1){

			segundos = i2c_read (ADDRESS_I2C_DS3231, SECONDS);
			minutos = i2c_read (ADDRESS_I2C_DS3231, MINUTES);
			horas = i2c_read (ADDRESS_I2C_DS3231, HOURS);

			writeStringlcd("---PASTILLERO---");

			displayAddress(0,1);
			writeStringlcd("Hora: ");
			writeCharlcd (asciiConvLcd_Dig2(horas));
			writeCharlcd (asciiConvLcd_Dig1(horas));
			writeCharlcd (':');
			writeCharlcd (asciiConvLcd_Dig2(minutos));
			writeCharlcd (asciiConvLcd_Dig1(minutos));
			writeCharlcd (':');
			writeCharlcd (asciiConvLcd_Dig2(segundos));
			writeCharlcd (asciiConvLcd_Dig1(segundos));

			if (alarma_1_seg == segundos){
				servo_set_D0(c);
				msleep(1000);			
				}
			if (alarma_2_seg == segundos){
				servo_set_D0(c);
				msleep(1000);			
				}	
			if (alarma_3_seg == segundos){
				servo_set_D0(b);
				msleep(1000);			
				}	
			if (alarma_4_seg == segundos){
				servo_set_D0(b);
				msleep(1000);			
				}	

	
						
			/*servo_set_D0(c);
			msleep(3000);	
			servo_set_D0(b);
			msleep(3000);
			servo_set_D3(c);
			servo_set_D2(c);
			msleep(100000);

			servo_set_D3(b);
			servo_set_D2(b);
			msleep(100000);
*/
			clearDisplay();
			returnHome();
			
		}
	return 0;

}

