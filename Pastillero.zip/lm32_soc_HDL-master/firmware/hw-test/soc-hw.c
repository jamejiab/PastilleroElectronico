#include "soc-hw.h"

uart_t  *uart0  = (uart_t *)   0x20000000;
timer_t *timer0 = (timer_t *)  0x30000000;
gpio_t  *gpio0  = (gpio_t *)   0x40000000;
spi_t   *spi0   = (spi_t *)    0x70000000;
i2c_t   *i2c0   = (i2c_t *)    0x60000000;
servo_t *servo0 = (servo_t *)  0x50000000;

isr_ptr_t isr_table[32];


void tic_isr();
/***************************************************************************
 * IRQ handling
 */
void isr_null()
{
}

void irq_handler(uint32_t pending)
{
	int i;

	for(i=0; i<32; i++) {
		if (pending & 0x01) (*isr_table[i])();
		pending >>= 1;
	}
}

void isr_init()
{
	int i;
	for(i=0; i<32; i++)
		isr_table[i] = &isr_null;
}

void isr_register(int irq, isr_ptr_t isr)
{
	isr_table[irq] = isr;
}

void isr_unregister(int irq)
{
	isr_table[irq] = &isr_null;
}

/***************************************************************************
 * TIMER Functions
 */
void msleep(uint32_t msec)
{
	uint32_t tcr;

	// Use timer0.1
	timer0->compare1 = (FCPU/1000)*msec;
	timer0->counter1 = 0;
	timer0->tcr1 = TIMER_EN;

	do {
		//halt();
 		tcr = timer0->tcr1;
 	} while ( ! (tcr & TIMER_TRIG) );
}

void nsleep(uint32_t nsec)
{
	uint32_t tcr;

	// Use timer0.1
	timer0->compare1 = (FCPU/1000000)*nsec;
	timer0->counter1 = 0;
	timer0->tcr1 = TIMER_EN;

	do {
		//halt();
 		tcr = timer0->tcr1;
 	} while ( ! (tcr & TIMER_TRIG) );
}


uint32_t tic_msec;

void tic_isr()
{
	tic_msec++;
	timer0->tcr0     = TIMER_EN | TIMER_AR | TIMER_IRQEN;
}

void tic_init()
{
	tic_msec = 0;

	// Setup timer0.0
	timer0->compare0 = (FCPU/10000);
	timer0->counter0 = 0;
	timer0->tcr0     = TIMER_EN | TIMER_AR | TIMER_IRQEN;

	isr_register(1, &tic_isr);
}


/***************************************************************************
 * UART Functions
 */
void uart_init()
{
	//uart0->ier = 0x00;  // Interrupt Enable Register
	//uart0->lcr = 0x03;  // Line Control Register:    8N1
	//uart0->mcr = 0x00;  // Modem Control Register

	// Setup Divisor register (Fclk / Baud)
	//uart0->div = (FCPU/(57600*16));
}

char uart_getchar()
{   
	while (! (uart0->ucr & UART_DR)) ;
	return uart0->rxtx;
}

void uart_putchar(char c)
{
	while (uart0->ucr & UART_BUSY) ;
	uart0->rxtx = c;
}

void uart_putstr(char *str)
{
	char *c = str;
	while(*c) {
		uart_putchar(*c);
		c++;
	}
}



/******************************************************************************
* i2c Functons
*/

void start_Read (int r)
{  i2c0->startRead = r;
}
void start_Write (int w)
{  i2c0->startWrite = w;
}
void start_Write_lcd (int wlcd)
{  i2c0->startWrite_lcd = wlcd;
}
void rw(int data_rw)
{  i2c0->rw = data_rw;
}

void i2c_write (int dirI2C, int dirIntern, int data)
{		
	i2c0->data = ((dirI2C<<16)|(dirIntern<<8)|data);	
	rw(0);
	start_Write(1);
   	nsleep(20000);
   	start_Write(0);
	
        while(!((i2c0->availWrite)==0x01));
}

void i2c_write_lcd (int dirI2C, int data)
{		
	i2c0->data = ((dirI2C<<8)|data);
 	rw(2);
	start_Write_lcd(1);
   	nsleep(20000);
   	start_Write_lcd(0);

        while(!((i2c0->availWrite)==0x01));
}

char i2c_read (int dirI2C, int dirIntern)
{  
	i2c0->data = ((dirI2C<<15)|(dirIntern<<7)|dirI2C);
	rw(1);
	start_Read(1);
   	nsleep(20000);
	start_Read(0);

	while(!((i2c0->availRead)==0x05));

	return i2c0->i2c_data_out;
}

/*****************************************************************************
* SERVO Functions
*/
void servo_put_T0(int c)
{
	
	servo0->servo_T0 = c;
}

void servo_put_D0(int c)
{
	
	servo0->servo_D0 = c;
}
void servo_put_T1(int c)
{
	
	servo0->servo_T1 = c;
}

void servo_put_D1(int c)
{
	
	servo0->servo_D1 = c;
}
void servo_put_T2(int c)
{
	
	servo0->servo_T2 = c;
}

void servo_put_D2(int c)
{
	
	servo0->servo_D2 = c;
}
void servo_put_T3(int c)
{
	
	servo0->servo_T3 = c;
}

void servo_put_D3(int c)
{
	
	servo0->servo_D3 = c;
}



void servo_set_T0(unsigned int c)
{      
	
	unsigned int a = 100000*c;
	servo0->servo_T0 = a;
	
}

void servo_set_D0(unsigned int c)
{
	unsigned int tmp = (c * 100000);
	unsigned int b = (tmp/180);
	unsigned int g = b + 100000;
	servo0->servo_D0 = g;
}
void servo_set_T1(unsigned int c)
{       
	unsigned int a = 100000*c;
	servo0->servo_T1 = a;
}


void servo_set_D1(unsigned int c)
{
	unsigned int tmp = (c * 10000);
	unsigned int b = (tmp/18);
	unsigned int g = b + 100000;
	servo0->servo_D1 = g;
}
void servo_set_T2(unsigned int c)
{       
	unsigned int a = 100000*c;
	servo0->servo_T2 = a;
}


void servo_set_D2(unsigned int c)
{
	unsigned int tmp = (c * 10000);
	unsigned int b = (tmp/18);
	unsigned int g = b + 100000;
	servo0->servo_D2 = g;
}
void servo_set_T3(unsigned int c)
{       
	unsigned int a = 100000*c;
	servo0->servo_T3 = a;
}


void servo_set_D3(unsigned int c)
{
	unsigned int tmp = (c * 10000);
	unsigned int b = (tmp/18);
	unsigned int g = b + 100000;
	servo0->servo_D3 = g;
}


